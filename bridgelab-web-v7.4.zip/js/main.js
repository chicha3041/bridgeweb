import { BridgeAnalyzer } from "./analyzer.js";
import { DdsClient } from "./dds-client.js";
import { loadStats, clearStats, registrarEstadisticas, eventKey, eventOptions, teamOptions } from "./stats.js";
import { renderReport, renderStats } from "./report.js";
import { exportToPdf } from "./export-pdf.js";
import { exportToExcel } from "./export-xlsx.js";
import { readRoom, normalizeBridgedomEvent } from "./room-input.js";

import { readTeamNames } from "./team-input.js";

const $ = (id) => document.getElementById(id);
let lastAnalyzer = null;
let selectedEvent = "";
let selectedTeam = "";
function refreshSelector(preferred, preferredTeam = selectedTeam) {
  const stats = loadStats();
  const selector = $("event-filter");
  const events = eventOptions(stats);
  selector.replaceChildren(new Option("Global - todos los eventos", ""),
    ...events.map(([key, label]) => new Option(label, key)));
  selector.value = events.some(([key]) => key === preferred) ? preferred : "";
  selectedEvent = selector.value;
  const teamSelector = $("team-filter");
  const teams = teamOptions(stats, selectedEvent);
  teamSelector.replaceChildren(new Option("Todos los equipos", ""),
    ...teams.map(([id, team]) => new Option(team.name, id)));
  teamSelector.value = teams.some(([id]) => id === preferredTeam) ? preferredTeam : "";
  selectedTeam = teamSelector.value;
  teamSelector.disabled = !teams.length;
  $("clear-event-btn").disabled = !selectedEvent;
  if (lastAnalyzer) renderReport(lastAnalyzer, stats, $("report"), selectedEvent, selectedTeam);
  else renderStats(stats, $("report"), selectedEvent, selectedTeam);
}


function setStatus(msg) { $("status").textContent = msg; }
function setProgress(f) { $("progress").value = f; }

async function analyze() {
  const openInput = $("file-open");
  const closedInput = $("file-closed");
  if (!openInput.files.length && !closedInput.files.length) { setStatus("Sube al menos un archivo PBN o LIN."); return; }

  $("analyze-btn").disabled = true;
  $("report").innerHTML = "";
  try {
    setStatus("Leyendo archivos y manos...");
    const open = await readRoom(openInput.files, "Abierta");
    const closed = await readRoom(closedInput.files, "Cerrada");
    setStatus("Cargando motor de análisis (DDS/WASM)...");
    const dds = new DdsClient();
    const analyzer = new BridgeAnalyzer(dds);
    analyzer.sourceFiles = [open, closed].filter(Boolean).flatMap(f => f.sourceNames);
    analyzer.singleTable = !(open && closed);

    const rooms = [];
    if (open) rooms.push([open, "Abierta"]);
    if (closed) rooms.push([closed, analyzer.singleTable ? "Abierta" : "Cerrada"]);

    const parsed = rooms.map(([input, room]) => [input.boards, room]);
    analyzer.teamNames = readTeamNames(parsed, {"Equipo A": $("team-a-name").value, "Equipo B": $("team-b-name").value});
    const totalBoards = parsed.reduce((n, [boards]) => n + boards.length, 0);
    if (parsed.length === 2) {
      const [a, c] = parsed.map(([boards]) => boards.map(b => b.boardNum).join(","));
      if (a !== c) throw new Error("Las salas no tienen las mismas manos. Revisa los archivos de cada sala.");
    }
    // Bridgedom distingue la mesa en Event; ambas salas pertenecen al mismo partido.
    for (const [boards] of parsed) for (const b of boards) normalizeBridgedomEvent(b);
    // Evitar que un archivo con distintos eventos mezcle ligas silenciosamente.
    const eventKeys = new Set(parsed.flatMap(([boards]) => boards.map(b => eventKey(b.info.Event))));
    if (eventKeys.size > 1) throw new Error("Los PBN contienen eventos diferentes. Sepáralos por evento antes de analizarlos.");
    const canonical = b => ({boardNum:b.boardNum, vul:b.vul, dealer:b.dealer,
      hands:b.hands, contract:b.contract, auction:b.auction, play:b.play,
      names:["North","East","South","West"].map(k=>b.info[k]),
      event:eventKey(b.info.Event), date:b.info.Date || ""});
    analyzer.matchIdentity = (analyzer.singleTable ? "MESA-UNICA\n" : "DOS-SALAS\n") +
      parsed.map(([boards]) => JSON.stringify(boards.map(canonical))).sort().join("\n---SALA---\n");
    // Identidad v6.1: permite sustituir el partido guardado antes de esta actualización.
    analyzer.legacyMatchIdentity = [open,closed].filter(Boolean).every(f => f.legacyText != null) ?
      [open,closed].filter(Boolean).map(f=>f.legacyText).sort().join("\n---SALA---\n") : null;
    let done = 0;
    for (const [boards, room] of parsed) {
      for (const b of boards) {
        setStatus(`Analizando mano ${b.boardNum} (sala ${room.toLowerCase()})...`);
        await analyzer.analyzeDeal(b, room);
        done++;
        setProgress(done / totalBoards);
      }
    }
    setStatus("Calculando atribución de IMPs...");
    analyzer.finalizeAnalysis();
    const stats = await registrarEstadisticas(analyzer);
    lastAnalyzer = analyzer;
    refreshSelector((analyzer.singleTable ? "mesa-unica:" : "") + eventKey(analyzer.matchEvent));
    $("export-btn").disabled = false;
    $("pdf-btn").disabled = false;
    setStatus(Object.values(analyzer.teamNames).every(Boolean) ? "Análisis completo." :
      "Análisis completo. El PBN no identifica todos los equipos: indica sus nombres por asientos arriba o usa el lápiz del histórico.");
    setProgress(1);
  } catch (err) {
    console.error(err);
    setStatus("Error: " + (err && err.message || err));
  } finally {
    $("analyze-btn").disabled = false;
  }
}

$("analyze-btn").addEventListener("click", analyze);
$("export-btn").addEventListener("click", async () => {
  if (!lastAnalyzer) return;
  setStatus("Generando Excel...");
  try {
    await exportToExcel(lastAnalyzer, loadStats(), selectedEvent, selectedTeam);
    setStatus("Excel descargado.");
  } catch (err) {
    console.error(err);
    setStatus("Error al generar el Excel: " + (err && err.message || err));
  }
});
$("pdf-btn").addEventListener("click", async () => {
  if (!lastAnalyzer) return;
  setStatus("Generando PDF...");
  try {
    await exportToPdf(lastAnalyzer, loadStats(), selectedEvent, selectedTeam);
    setStatus("PDF descargado.");
  } catch (err) { setStatus("Error al generar el PDF: " + (err?.message || err)); }
});
$("clear-stats-btn").addEventListener("click", () => {
  if (confirm("¿Borrar todo el histórico de partidos guardado en este navegador?")) {
    clearStats();
    setStatus("Histórico borrado.");
    refreshSelector("");
  }
});

$("report").addEventListener("teams-renamed", () => refreshSelector(selectedEvent, ""));
$("event-filter").addEventListener("change", () => refreshSelector($("event-filter").value));
$("team-filter").addEventListener("change", () => refreshSelector(selectedEvent, $("team-filter").value));
$("clear-event-btn").addEventListener("click", () => {
  const key = $("event-filter").value;
  const label = $("event-filter").selectedOptions[0].textContent;
  if (key && confirm(`¿Borrar solo los partidos de «${label}» guardados en este navegador?`)) {
    clearStats(key);
    refreshSelector("");
    setStatus(`Histórico de «${label}» borrado.`);
  }
});
try { refreshSelector(""); } catch (err) {
  console.error(err);
  setStatus("No se pudo leer el histórico: " + err.message);
}

for (const id of ["file-open", "file-closed"]) $(id).addEventListener("change", () => {
  $("team-a-name").value = ""; $("team-b-name").value = "";
});
